from test.test_scheduler import StartTestPlan

StartTestPlan()