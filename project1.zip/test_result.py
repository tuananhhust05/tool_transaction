from test.test_result import StartTestResult

StartTestResult()