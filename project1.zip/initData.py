from tool.transaction.deleteTransaction import DeleteTransaction
from tool.transaction.insertDataTest import InsertTransaction
DeleteTransaction()
InsertTransaction()