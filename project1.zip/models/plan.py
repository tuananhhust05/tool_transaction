class Plan:
    def __init__ (self, id,created_at,time_change):
        self.id = id
        self.created_at = created_at
        self.time_change = time_change