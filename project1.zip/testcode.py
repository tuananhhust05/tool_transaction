from tzlocal import get_localzone
tz = get_localzone()
print(tz)